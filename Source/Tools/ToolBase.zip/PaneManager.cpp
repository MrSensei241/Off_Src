#include "stdafx.h"

#include "DClient.h"
#include "MainFrm.h"
#include "PaneManager.h"
#include "PaneLogin.h"
#include "PaneIESList.h"
#include "PaneIESView.h"

// CMainFrame
static CPaneManager s_paneManager;
static CMainFrame*	s_pMainFrame  = NULL;

CPaneView* PANE_INFO::GetPaneView()
{
	return (CPaneView*) wnd;
}

CDialog* PANE_INFO::GetDialog()
{
	return (CDialog*) wnd;
}

CPaneManager& GetPaneManager()
{	
	return s_paneManager;
}

// NOTE :  PaneManager
CPaneManager::CPaneManager() 
{		

}

CPaneManager::~CPaneManager()
{
	DeleteAllPanes();

}

void CPaneManager::Init(CMainFrame* pMainFrame)
{
	s_pMainFrame = pMainFrame;

	m_pDockingPaneManager = new CXTPDockingPaneManager;

	m_pDockingPaneManager->InstallDockingPanes((CWnd*)s_pMainFrame);
	m_pDockingPaneManager->SetTheme(xtpPaneThemeOffice2007);
	
	CreatePanes();

	// Note : ���� ������ ����
	//int nIDIcons[] = {IDR_PANE_EFFECTLIST, IDR_PANE_PROPERTIES, IDR_PANE_PLAYER, IDR_PANE_PLAYOPTION, IDR_PANE_PLAYACTION};
	//m_pDockingPaneManager->SetIcons(IDB_BITMAP_ICONS, nIDIcons, _countof(nIDIcons), RGB(0, 255, 0));	
}

#define EFFECTEDITOR_LAYOUTNAME "iesmanager_layout_1"

void CPaneManager::Exit()
{
	// Save the current state for docking panes.
	/*CXTPDockingPaneLayout layoutNormal(m_pDockingPaneManager);
	m_pDockingPaneManager->GetLayout(&layoutNormal);
	layoutNormal.Save(_T(EFFECTEDITOR_LAYOUTNAME));*/

	// NOTE : �� ���� ����
	m_pDockingPaneManager->DestroyAll();

	SAFE_DELETE(m_pDockingPaneManager);

	DeleteAllPanes();
}

PANE_INFO* CPaneManager::GetPaneInfo(UINT id)
{
	int index = m_dlgList.Find(id);
	if (index != m_dlgList.InvalidIndex())
		return &m_dlgList.Element(index);

	return NULL;
}

CXTPDockingPane* CPaneManager::CreateDockPane(CWnd* wnd, UINT paneID, PANE_TYPE type, UINT dlgID, const CRect& rect, XTPDockingPaneDirection dir)
{
	PANE_INFO info;
	info.wnd = wnd;
	info.pane = NULL;
	info.type = type;
	info.dlgID = dlgID;

	CXTPDockingPane* pane = m_pDockingPaneManager->CreatePane(paneID, rect, dir);
	m_dlgList.Insert(paneID, info);
	return pane;
}

// NOTE : Pane ����
void CPaneManager::CreatePanes()
{	
	// Load the previous state for docking panes.
	/*CXTPDockingPaneLayout layoutNormal(m_pDockingPaneManager);
	if (layoutNormal.Load(_T(EFFECTEDITOR_LAYOUTNAME)))
	{		
//#ifndef _DEBUG
		m_pDockingPaneManager->SetLayout(&layoutNormal);
//#endif		
	}*/

	CXTPDockingPane* paneLogin = CreateDockPane(new CPaneLogin, IDR_LOGIN_PANE, PANE_DIALOG, IDD_LOGIN_DLG, CRect(0, 0, 300, 1400), xtpPaneDockTop);
	CXTPDockingPane* paneIES = CreateDockPane(new CPaneIESList, IDR_IES_PANE, PANE_DIALOG, IDD_IES_DLG, CRect(0, 0, 300, 1400), xtpPaneDockTop);
	// CXTPDockingPane* pDockPaneDead	= CreateDockPane(new CPaneIESView, IDR_IES_VIEW, PANE_VIEW, CRect(0, 0, 700, 1400), xtpPaneDockTop);
	//pDockPaneDead->Close();


 	m_pDockingPaneManager->SetAlphaDockingContext(TRUE);
 	m_pDockingPaneManager->SetShowDockingContextStickers(TRUE);
 	m_pDockingPaneManager->SetShowContentsWhileDragging(TRUE);
}

void CPaneManager::DeleteAllPanes()
{

}

CXTPDockingPane* CPaneManager::GetActivePane()
{
	return m_pDockingPaneManager->GetActivePane();
}

CWnd* CPaneManager::GetActivePaneView()
{
	CXTPDockingPane* pActivePane = GetActivePane();
	if (pActivePane)
		return pActivePane->GetChild();
	return NULL;
}

void CPaneManager::UpdateSelection()
{

}

LRESULT CPaneManager::OnDockingPaneNotify(WPARAM wParam, LPARAM lParam)
{
	switch (wParam)
	{
	case XTP_DPN_CLOSEPANE:		
		{
			CXTPDockingPane* pPane = (CXTPDockingPane*)lParam;
			/*switch (pPane->GetID())	
			{
			case IDR_PANE_COMPONENTLIST:			

				break;
			}*/
			break;
		}

	case XTP_DPN_SHOWWINDOW:
		{
			CXTPDockingPane* pPane = (CXTPDockingPane*)lParam;
			if (pPane->IsValid()) 
				return TRUE;

			m_paneMap.Insert(pPane->GetID(), pPane);

			UINT paneID = pPane->GetID();
			PANE_INFO* info = GetPaneInfo(paneID);

			if (info->type == PANE_DIALOG)
			{
				if (info->pane == NULL)
				{
					info->pane = pPane;

					if (!::IsWindow(info->wnd->m_hWnd))
					{
						info->GetDialog()->Create(info->dlgID, s_pMainFrame);							
					}
				}
				
				pPane->Attach(info->wnd);
			} else if (info->type == PANE_VIEW)
			{
				if (info->pane == NULL)
				{
					info->pane = pPane;
					info->GetPaneView()->SetID(pPane->GetID());				
				}
				pPane->Attach(info->GetPaneView()->CreatePane(s_pMainFrame));
			}
		}
	default:
		break;
	}

	return TRUE;
}

BOOL CPaneManager::CommandProcess(UINT id)
{
	return TRUE;
}

void CPaneManager::CommandUpdateProcess(UINT id, CCmdUI *pCmdUI)
{
	

};

CDialog* CPaneManager::GetDialog(UINT id)
{
	PANE_INFO* info = GetPaneInfo(id);
	return (CDialog*) info->wnd;
}

CPaneView* CPaneManager::GetPaneView(UINT id)
{
	PANE_INFO* info = GetPaneInfo(id);
	return (CPaneView*) info->wnd;
}


CPaneLogin* CPaneManager::GetPaneLogin()
{
	PANE_INFO* info = GetPaneInfo(IDR_LOGIN_PANE);
	return (CPaneLogin*) info->wnd;
}

CPaneIESList* CPaneManager::GetPaneIESList()
{
	PANE_INFO* info = GetPaneInfo(IDR_IES_PANE);
	return (CPaneIESList*) info->wnd;
}

void CPaneManager::ShowPane(UINT id, BOOL isShow)
{
	CXTPDockingPane* pane = m_paneMap.FindAndGet(id);
	if (pane != NULL)
	{
		if (isShow == TRUE)
			pane->Select();
		else		
			pane->Close();
	}
	else if (isShow == TRUE)
	{
		m_pDockingPaneManager->ShowPane(m_paneMap.Key(id), TRUE);
	}
}
/*
void CPaneManager::ShowLoginPane(BOOL isShow)
{
	if (m_pdockpanelogin != NULL)
	{
		if (isShow == TRUE)
			m_pdockpanelogin->Select();
		else		
			m_pdockpanelogin->Close();
	}
	else if (isShow == TRUE)
	{
		m_pDockingPaneManager->ShowPane(IDR_LOGIN_PANE, TRUE);
	}
}

void CPaneManager::ShowIESPane(BOOL isShow)
{
	if (m_pdockIESVIEW != NULL)
	{
		if (isShow == TRUE)
			m_pdockIESVIEW->Select();
		else		
			m_pdockIESVIEW->Close();
	}
	else if (isShow == TRUE)
	{
		m_pDockingPaneManager->ShowPane(IDR_IES_VIEW, TRUE);
	}
}
*/





