#pragma once



namespace uiutil
{
	void BuildIDSpaceTree(CTreeCtrl& tree, imc::CStringID idSpace);
	imc::CStringID GetEditText(CEdit& edit);

};


