#pragma once



namespace util
{

	std::string GetConfigIniPath();
	void InitTool();
	void ExitTool();

	void InitServerList();
	void WriteLastLoginInfo();	
	void UpdatePaneVisible();
	void UpdateAllHistory();

	


};


