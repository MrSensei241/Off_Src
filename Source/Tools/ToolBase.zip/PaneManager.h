#pragma once


class CPaneLogin;
class CPaneIESList;
class CMainFrame;
class CPaneIESView;

enum TREE_TYPE
{
	TREE_IDSPACE,
	TREE_CLASSNAME,
};

enum PANE_TYPE
{
	PANE_DIALOG,
	PANE_VIEW,
	PANE_TYPE_CNT,
};

class CPaneView;

struct PANE_INFO
{
	CWnd* wnd;
	CPaneView*	GetPaneView();
	CDialog*	GetDialog();
	CXTPDockingPane* pane;
	PANE_TYPE	type;
	UINT dlgID;
};

typedef imc::CMap<UINT, PANE_INFO> PANE_LIST;

class CPaneManager
{
public:

	CPaneManager();
	virtual				~CPaneManager();

	void				Init(CMainFrame* pMainFrame);
	void				Exit();
	PANE_INFO*			GetPaneInfo(UINT id);
	
	void				UpdateSelection();
	LRESULT				OnDockingPaneNotify(WPARAM wParam, LPARAM lParam);
	BOOL				CommandProcess(UINT id);
	CWnd*				GetActivePaneView();
	CXTPDockingPane*	GetActivePane();
	void				CommandUpdateProcess(UINT id, CCmdUI *pCmdUI);
	
	CDialog*			GetDialog(UINT id);
	CPaneView*			GetPaneView(UINT id);
	CPaneLogin*			GetPaneLogin();
	CPaneIESList*		GetPaneIESList();

	void				ShowPane(UINT id, BOOL isShow);
	/*void				ShowLoginPane(BOOL isShow);
	void				ShowIESPane(BOOL isShow);
	void				ShowIESViewPane(BOOL isShow);*/

protected:

	void				CreatePanes();
	CXTPDockingPane*	CreateDockPane(CWnd* wnd, UINT paneID, PANE_TYPE type, UINT dlgID, const CRect& rect, XTPDockingPaneDirection dir);
	void				DeleteAllPanes();
	
private:

	CXTPDockingPaneManager*	m_pDockingPaneManager;

	imc::CMap<int, CXTPDockingPane*>	m_paneMap;
	PANE_LIST			m_dlgList; //[PANE_TYPE_CNT];

			

};

CPaneManager& GetPaneManager();