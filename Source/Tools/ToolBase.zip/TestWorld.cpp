#include "StdAfx.h"

#include "TestWorld.h"

namespace geapp{

	CTestWorld::CTestWorld()
	{



	}
	
	CTestWorld::~CTestWorld()
	{

	};

	void CTestWorld::OnCreate(const char* worldFileName, const char* renderFileName, const char* pMtlfileName, const char* pLightFileName)
	{

	}
};