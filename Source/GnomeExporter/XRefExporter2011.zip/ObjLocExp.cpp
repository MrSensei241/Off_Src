/***
*
*	Copyright (c) 2010, IMC. All rights reserved.
*
****/

#define _CRT_SECURE_NO_WARNINGS

#include "MAX.H"
#include "DECOMP.H"
#include "XRef/iXrefObj.h"
#include "modstack.h"
#include "tinyxml.h"

#include "resource.h"
#include "ObjLocExp.h"

//===================================================================
// Prototype declarations
//
int GetIndexOfINode(INode *pnode,BOOL fAssertPropExists = TRUE);
void SetIndexOfINode(INode *pnode, int inode);
BOOL FUndesirableNode(INode *pnode);
BOOL FNodeMarkedToSkip(INode *pnode);
float FlReducenml_Rot(float fl);


bool ExtractNETName(const char* objName, char type, char* netName);


//===================================================================
// Global variable definitions
//

// Save for use with dialogs
static HINSTANCE hInstance;

// We just need one of these to hand off to 3DSMAX.
static CObjLocExportDesc CObjLocExportCD;

// For OutputDebugString and misc sprintf's
static char st_szDBG[300];

// INode mapping table
static int g_inmMac = 0;

//===================================================================
// Utility functions
//

static int AssertFailedFunc(char *sz)
{
	MessageBox(GetActiveWindow(), sz, "Assert failure", MB_OK);
	int Set_Your_Breakpoint_Here = 1;
	return 1;
}
#define ASSERT_MBOX(f, sz) ((f) ? 1 : AssertFailedFunc(sz))


//===================================================================
// Required plug-in export functions
//
BOOL WINAPI DllMain( HINSTANCE hinstDLL, ULONG fdwReason, LPVOID lpvReserved) 
{	
	static int fFirstTimeHere = TRUE;
	if (fFirstTimeHere)
	{
		fFirstTimeHere = FALSE;
		hInstance = hinstDLL;
	}
	return TRUE;
}


EXPORT_THIS int LibNumberClasses(void)
{
	return 1;
}


EXPORT_THIS ClassDesc *LibClassDesc(int iWhichClass)
{
	switch(iWhichClass)
	{
		case 0: return &CObjLocExportCD;
		default: return 0;
	}
}


EXPORT_THIS const TCHAR *LibDescription()
{
	return _T("IMC Grome ObjectGroup Export");
}

	
EXPORT_THIS ULONG LibVersion()
{
	return VERSION_3DSMAX;
}


//=====================================================================
// Methods for CObjLocExport
//

CONSTRUCTOR CObjLocExport::CObjLocExport(void)
{
	m_rgNodeExpInfo = NULL;
}


DESTRUCTOR CObjLocExport::~CObjLocExport(void)
{
}


int CObjLocExport::DoExport(const TCHAR *name,ExpInterface *ei,Interface *i, BOOL suppressPrompts, DWORD options) 
{
	ExpInterface	*pexpiface = ei;	// Hungarian
	Interface		*piface = i;		// Hungarian

	// Reset the name-map property manager
	g_inmMac = 0;

	m_iCurNode = 0;
	m_iNodeExpInfoMac = 0;

	// Break up filename, re-assemble longer versions
	TSTR strPath, strFile, strExt;
	TCHAR szFile[MAX_PATH];
	SplitFilename(TSTR(name), &strPath, &strFile, &strExt);

	sprintf(szFile, "%s\\%s.%s", (char*)strPath, (char*)strFile, "objgroup");

	// Count nodes, label them, collect into array
	if (!CollectNodes(pexpiface))
		return 0;	/*fail*/

	// Output nodes
	if (!DumpNodes(pexpiface))
		return 0;	/*fail*/

	SaveDocument(szFile);

	// Tell user that exporting is finished (it can take a while with no feedback)
	char szExportComplete[300];
	sprintf(szExportComplete, "Exported %s.", szFile);
	MessageBox(GetActiveWindow(), szExportComplete, "Status", MB_OK);

	if (m_rgNodeExpInfo) {
		delete [] m_rgNodeExpInfo;
		m_rgNodeExpInfo = NULL;
	}

	return 1/*success*/;
}

BOOL CObjLocExport::SaveDocument(LPCTSTR lpszPathName)
{
	TiXmlDocument		saveFile;
	TiXmlDeclaration	decl("1.0", "", "yes");
	TiXmlElement		world("Instances");
	world.SetAttribute("Name", "[Group]");
	world.SetAttribute("Opened", "false");
	for( int i = 0; i < m_iNodeExpInfoMac; i++ ) {
		CObjLocExport::NodeExpInfo* pExpInfo = &m_rgNodeExpInfo[i];
		if(pExpInfo->type != CObjLocExport::NETYPE_NORMAL) {
			continue;
		}

		TiXmlElement elem("Instance");
		char tmp[1024];

		elem.SetAttribute("Name", pExpInfo->objName);
		elem.SetAttribute("Template", pExpInfo->objTemplate);
		elem.SetAttribute("Path",  pExpInfo->objPath);

		sprintf( tmp, "%.4f %.4f %.4f", pExpInfo->pos.x, pExpInfo->pos.y, pExpInfo->pos.z);
		elem.SetAttribute("pos", tmp);
		sprintf( tmp, "%.4f %.4f %.4f", pExpInfo->rot.x, pExpInfo->rot.y, pExpInfo->rot.z);
		elem.SetAttribute("rot", tmp);
		sprintf( tmp, "%.4f %.4f %.4f", pExpInfo->scl.x, pExpInfo->scl.y, pExpInfo->scl.z);
		elem.SetAttribute("scale", tmp);
		world.InsertEndChild(elem);
	}

	saveFile.InsertEndChild(decl);
	saveFile.InsertEndChild(world);
	saveFile.SaveFile(lpszPathName);

	return TRUE;        // success
}
	
BOOL CObjLocExport::CollectNodes( ExpInterface *pexpiface)
{
	// Count total nodes in the model, so I can alloc array
	// Also "brands" each node with node index, or with "skip me" marker.
	CountNodesTEP procCountNodes;
	procCountNodes.m_cNodes = 0;
	(void) pexpiface->theScene->EnumTree(&procCountNodes);
	ASSERT_MBOX(procCountNodes.m_cNodes > 0, "No nodes!");

	// Alloc and fill array
	m_iNodeExpInfoMac = procCountNodes.m_cNodes;
	m_rgNodeExpInfo = new NodeExpInfo[m_iNodeExpInfoMac];
	::ZeroMemory(m_rgNodeExpInfo, sizeof(NodeExpInfo)*m_iNodeExpInfoMac);

	return TRUE;
}

BOOL CObjLocExport::DumpNodes(ExpInterface *pexpiface)
{
	// Dump bone names
	DumpNodesTEP procDumpNodes;
	procDumpNodes.m_phec = this;

	(void) pexpiface->theScene->EnumTree(&procDumpNodes);

	return TRUE;
}

//=============================================================================
//							TREE-ENUMERATION PROCEDURES
//=============================================================================

#define ASSERT_AND_ABORT(f, sz)							\
	if (!(f))											\
	{													\
		ASSERT_MBOX(FALSE, sz);							\
		cleanup( );										\
		return TREE_ABORT;								\
	}

//=================================================================
// Methods for CountNodesTEP
//
int CountNodesTEP::callback( INode *node)
{
	INode *pnode = node; // Hungarian

	ASSERT_MBOX(!(pnode)->IsRootNode(), "Encountered a root node!");

	if (::FUndesirableNode(pnode))
	{
		// Mark as skippable
		::SetIndexOfINode(pnode, CObjLocExport::UNDESIRABLE_NODE_MARKER);
		return TREE_CONTINUE;
	}
	
	// Establish "node index"--just ascending ints
	::SetIndexOfINode(pnode, m_cNodes);

	m_cNodes++;
	
	return TREE_CONTINUE;
}

//========================================================================
// Utility functions for getting/setting the personal "node index" property.
// NOTE: I'm storing a string-property because I hit a 3DSMax bug in v1.2 when I
// NOTE: tried using an integer property.
// FURTHER NOTE: those properties seem to change randomly sometimes, so I'm
// implementing my own.

typedef struct
{
	char	szNodeName[CObjLocExport::MAX_NAME_CHARS];
	int		iNode;
} NAMEMAP;
const int MAX_NAMEMAP = 65535;
static NAMEMAP g_rgnm[MAX_NAMEMAP];

int GetIndexOfINode(INode *pnode, BOOL fAssertPropExists)
{
	TSTR strNodeName(pnode->GetName());
	for (int inm = 0; inm < g_inmMac; inm++)
		if (FStrEq(g_rgnm[inm].szNodeName, (char*)strNodeName))
			return g_rgnm[inm].iNode;
	if (fAssertPropExists)
		ASSERT_MBOX(FALSE, "No NODEINDEXSTR property");
	return -7777;
}

	
void SetIndexOfINode(INode *pnode, int inode)
{
	TSTR strNodeName(pnode->GetName());
	NAMEMAP *pnm;
	int inm = 0;
	for ( inm = 0; inm < g_inmMac; inm++)
		if (FStrEq(g_rgnm[inm].szNodeName, (char*)strNodeName))
			break;
	if (inm < g_inmMac)
		pnm = &g_rgnm[inm];
	else
	{
		ASSERT_MBOX(g_inmMac < MAX_NAMEMAP, "NAMEMAP is full");
		pnm = &g_rgnm[g_inmMac++];
		strcpy(pnm->szNodeName, (char*)strNodeName);
	}
	pnm->iNode = inode;
}

//=============================================================
// Returns TRUE if a node should be ignored during tree traversal.
//
BOOL FUndesirableNode(INode *pnode)
{
	// Get Node's underlying object, and object class name
	Object *pobj = pnode->GetObjectRef();

	// Don't care about lights, dummies, and cameras
	if (pobj->SuperClassID() == LIGHT_CLASS_ID)
		return TRUE;
	if (pobj->SuperClassID() == HELPER_CLASS_ID)
		return TRUE;
	if (pobj->SuperClassID() == CAMERA_CLASS_ID)
		return TRUE;

	return FALSE;
}


//=============================================================
// Returns TRUE if a node has been marked as skippable
//
BOOL FNodeMarkedToSkip(INode *pnode)
{
	return (::GetIndexOfINode(pnode) == CObjLocExport::UNDESIRABLE_NODE_MARKER);
}


//=============================================================
// Reduces a nml_Rot to within the -2PI..2PI range.
//
static float FlReducenml_Rot(float fl)
{
	while (fl >= TWOPI)
		fl -= TWOPI;
	while (fl <= -TWOPI)
		fl += TWOPI;
	return fl;
}

//=================================================================
// Node Export Type �̸��� �����Ѵ�.
//
bool ExtractNETName(const char* objName, char type, char* netName)
{
	if(objName[0]!='@')		return false;
	if(objName[1]!=type)	return false;

	int nameLen = (int)strlen(objName);
	for(int i=3; i<nameLen; ++i) {
		if(objName[i]==']') {
			int wordLen = i - 3;
			strncpy(netName, &objName[3], wordLen);
			netName[wordLen] = '\0';
		}
	}

	return true;
}

//=================================================================
// Methods for DumpNodesTEP
//
int DumpNodesTEP::callback(INode *pNode)
{
	ASSERT_MBOX(!(pNode)->IsRootNode(), "Encountered a root node!");

	CObjLocExport::NodeExpInfo* pExpInfo = &m_phec->m_rgNodeExpInfo[m_phec->m_iCurNode];

	if (::FNodeMarkedToSkip(pNode)) {
		pExpInfo->type = CObjLocExport::NETYPE_INVALID;
		return TREE_CONTINUE;
	}

	if(pNode->IsHidden()) {
		pExpInfo->type = CObjLocExport::NETYPE_INVALID;
		return TREE_CONTINUE;
	}

	Object* pObj = pNode->GetObjectRef();
	Object* pRefObj = pObj;
	TSTR strNodeName;
	switch(pObj->SuperClassID())
	{
	case SYSTEM_CLASS_ID:
		if (pObj->ClassID() == XREFOBJ_CLASS_ID) {
			IXRefObject *pXRefObj = (IXRefObject*)pObj;
			strNodeName = pXRefObj->GetObjName(FALSE);
		} else {
			pExpInfo->type = CObjLocExport::NETYPE_INVALID;
			return TREE_CONTINUE;
		}
		break;
	case GEOMOBJECT_CLASS_ID:
		strNodeName = pNode->GetName();
		break;
	case GEN_DERIVOB_CLASS_ID:
		{
			IDerivedObject* pDerivedObj = (IDerivedObject*)pObj;
			pRefObj = pDerivedObj->GetObjRef();
			if (pRefObj->SuperClassID() != GEOMOBJECT_CLASS_ID) {
				pExpInfo->type = CObjLocExport::NETYPE_INVALID;
				return TREE_CONTINUE;
			}

			BOOL bFind = FALSE;
			for (int i = 0; i < m_phec->m_iNodeExpInfoMac; i++) {
				CObjLocExport::NodeExpInfo* pOtherExpInfo = &m_phec->m_rgNodeExpInfo[i];
				if (pRefObj == pOtherExpInfo->pObj) {
					strNodeName = pOtherExpInfo->objName;
					bFind = TRUE;
					break;
				}
			}
			if (!bFind) {
				strNodeName = pNode->GetName();
			}
		}
		break;
	default:
		pExpInfo->type = CObjLocExport::NETYPE_INVALID;
		return TREE_CONTINUE;
	}

	pExpInfo->type = CObjLocExport::NETYPE_NORMAL;
	pExpInfo->pObj = pRefObj;
	strcpy(pExpInfo->objName, pNode->GetName());
	TSTR strNodeNameLower = strNodeName;
	strNodeNameLower.toLower();
	strcpy(pExpInfo->objTemplate, strNodeNameLower);
	strcpy(pExpInfo->objPath, strNodeName);

	int len = (int)strlen(pExpInfo->objPath);
	strcpy(&(pExpInfo->objPath[len]), ".mesh");

	AffineParts affparts;
	decomp_affine(pNode->GetNodeTM(0), &affparts);

	pExpInfo->pos.x = abs(affparts.t.x) < 0.00005f ? 0.0f : affparts.t.x;
	pExpInfo->pos.y = abs(affparts.t.z) < 0.00005f ? 0.0f : affparts.t.z;
	pExpInfo->pos.z = abs(affparts.t.y) < 0.00005f ? 0.0f : affparts.t.y;
	pExpInfo->scl = Point3(affparts.k.x, affparts.k.z, affparts.k.y);

	Quat quat(affparts.q.x, affparts.q.z, affparts.q.y, affparts.q.w);
	float sqx = quat.x * quat.x;
	float sqy = quat.y * quat.y;
	float sqz = quat.z * quat.z;
	float sqw = quat.w * quat.w;
	float unit = sqx + sqy + sqz + sqw;
	float test = quat.x * quat.y + quat.z * quat.w;
	if (test > 0.499f * unit) {
		pExpInfo->rot.x = 0.0f;
		pExpInfo->rot.y = 2 * atan2f(quat.x, quat.w);
		pExpInfo->rot.z = PI / 2;
	} else if (test < -0.499f * unit) {
		pExpInfo->rot.x = 0.0f;
		pExpInfo->rot.y = -2 * atan2f(quat.x, quat.w);
		pExpInfo->rot.z = -PI / 2;
	} else {
		pExpInfo->rot.x = atan2f(2 * (quat.x * quat.w - quat.y * quat.z), 1 - 2 * (sqx + sqz));
		pExpInfo->rot.y = atan2f(2 * (quat.y * quat.w - quat.x * quat.z), 1 - 2 * (sqy + sqz));
		pExpInfo->rot.z = asinf(2 * (quat.x * quat.y + quat.z * quat.w));
	}
	pExpInfo->rot.x = abs(pExpInfo->rot.x) < 0.00005f ? 0.0f : -pExpInfo->rot.x;
	pExpInfo->rot.y = abs(pExpInfo->rot.y) < 0.00005f ? 0.0f : -pExpInfo->rot.y;
	pExpInfo->rot.z = abs(pExpInfo->rot.z) < 0.00005f ? 0.0f : -pExpInfo->rot.z;

	MSTR userPropBuffer;
	pNode->GetUserPropBuffer(userPropBuffer);
	userPropBuffer.toLower();
	if (userPropBuffer == MSTR("objectpaintx") || userPropBuffer == MSTR("objectpaintz")) {
		pExpInfo->rot.z += 3.141592654f;
	}

	m_phec->m_iCurNode++;

	return TREE_CONTINUE;
}
