#ifndef __STDAFX
#define __STDAFX

#define _WIN32_WINNT 0x0500
#define _CRT_SECURE_NO_WARNINGS

#pragma warning(disable:4786)

#include <string>
#include <windows.h>
#include <windowsx.h>
#include <imm.h>

#endif
